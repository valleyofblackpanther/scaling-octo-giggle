let selectedId = [];
let attachmentData = [];

$(".loading").show();
$("#con").hide();

document.onreadystatechange = function () {
  if (document.readyState === "interactive") renderApp();

  function renderApp() {
    var onInit = app.initialized();

    onInit.then(getClient).catch(handleErr);

    function getClient(_client) {
      window.client = _client;
      client.events.on("app.activated", onAppActivate);
    }
  }
};

const fdGetRequest = (url, options) => {
  return new Promise((resolve, reject) => {
    client.request.get(url, options).then(
      (data) => resolve(data),
      (err) => reject(err)
    );
  });
};

const myDownload = () => {
  selectedId.map((id) => {
    window.open(
      "https://spritle2175.freshdesk.com" +
        "/helpdesk/attachments/" +
        id +
        "?download=true"
    );
  });
};

const myAttachments = () => {
  console.log("SELECTED ID >>>", selectedId);
  client.interface
    .trigger("setValue", { id: "editor", attachments: selectedId })
    .then(function (data) {
      console.log(data)
    })
    .catch(function (error) {
      console.log("ERROR >>>>>", error);
    });
};

const getEntireConversations = async function (pageNo = 1) {
  console.log("Page >> ", pageNo);

  const results = await getConversations(pageNo);
  $(".loading").hide();
  $("#con").show();
  console.log("Retreiving data from API for page :", results);

  if (results.length > 0) {
    return results.concat(await getEntireConversations(pageNo + 1));
  } else {
    return results;
  }
};

const getConversations = async (pageNo = 1) => {
  var headers = {
    Authorization: "Basic <%= encode(iparam.apiKey) %>",
    "Content-Type": "application/json",
  };
  var options = { headers: headers };
  // console.log("DOMAIN",iparams.FreshdeskDomain)
  //?include=conversations
  const iparams = await client.iparams.get();
  console.log("DOMAIN",iparams)
  var getTicket = await client.data.get('ticket');
  const ticketID = getTicket.ticket.id;




  const url = `https://${iparams.FreshdeskDomain}.freshdesk.com/api/v2/tickets/${ticketID}/conversations?page=${pageNo}&per_page=10`;

  const { response } = await fdGetRequest(url, options);

  const convData = JSON.parse(response);

 
  


  return convData;
};



/**
 * 
 * Pagination
 */


 var current_page = 1;
 var records_per_page = 5;


 function prevPage() {
  if (current_page > 1) {
    current_page--;
    changePage(current_page);
  }
}

function nextPage() {
  if (current_page < numPages()) {
    current_page++;
    changePage(current_page);
  }
}


function changePage(page) {
  console.log("Change Page Called >>");
  var btn_next = document.getElementById("btn_next");
  var btn_prev = document.getElementById("btn_prev");
  var listing_table = document.getElementById("listingTable");
  var page_span = document.getElementById("page");

  // Validate page
  if (page < 1) page = 1;
  if (page > numPages()) page = numPages();

  listing_table.innerHTML = "";

  for (
    var i = (page - 1) * records_per_page;
    i < page * records_per_page;
    i++
  ) {
    console.log("i >>", i);
    
    if(attachmentData[i]){
      listing_table.innerHTML += `<li class="row" > 
      <input style="margin-right: 5px;" id="accept" type='checkbox' onchange=change(event) value="${attachmentData[i].id}"/>
      <label for="accept" >
      <a style="color: white;"rel="nofollow" target="_blank"  href="${attachmentData[i].attachment_url}" >${attachmentData[i].name}[${attachmentData[i].size}kb]</a>
     </label>
     </li>`;
    }




  }
  listing_table.innerHTML += `<button style="background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 9px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;" onclick="myDownload(event)">download</button>`;

  listing_table.innerHTML += `<button style="background-color: #008CBA;; /* Green */
  border: none;
  color: white;
  padding: 5px 9px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;" onclick="myAttachments()">Attach</button>`;

  
  page_span.innerHTML = page;
 
  change = (event) => {
    const id = parseInt(event.target.value.trim(" "));
    console.log("ID >>>>>", id);
  
    console.log("STATE >>>>", event.target);
    if (event.target.checked === true) {
      selectedId.push(id);
      console.log(selectedId, "first")
    } else {
      let a = selectedId.filter((selectedId) => selectedId !== id)
      selectedId = a
      console.log(selectedId, "filtered")
      
    }

   
  };

 
  myAttachments();

  if (page == 1) {
    btn_prev.style.visibility = "hidden";
  } else {
    btn_prev.style.visibility = "visible";
  }

  if (page == numPages()) {
    btn_next.style.visibility = "hidden";
  } else {
    btn_next.style.visibility = "visible";
  }
}


function numPages() {
  return Math.ceil(attachmentData.length / records_per_page);
}



function onAppActivate() {
  var getContact = client.data.get("ticket");
  getContact.then(showContact).catch(handleErr);


}

async function showContact(payload) {
  console.log("rrr", payload);



  const converData = await getEntireConversations();



  converData.map((conv) => {
    if (conv && conv.attachments && conv.attachments.length > 0) {
      attachmentData.push(...conv.attachments);
    }
  });


  var headers = {
    Authorization: "Basic <%= encode(iparam.apiKey) %>",
    "Content-Type": "application/json",
  };
  var options = { headers: headers };


  const iparams = await client.iparams.get();
  console.log("DOMAIN",iparams)
  var getTicket = await client.data.get('ticket');
  const ticketID = getTicket.ticket.id;

  const ticketURL = `https://${iparams.FreshdeskDomain}.freshdesk.com/api/v2/tickets/${ticketID}`;

  const { response: ticketResponse } = await fdGetRequest(ticketURL, options);

  const ticketData = JSON.parse(ticketResponse);

  console.log("TICKET RESPONSE >>>",ticketData.attachments);

   const ticketAtt = ticketData.attachments;

    attachmentData.push(...ticketAtt);




  if(attachmentData.length > 0){
    changePage(1)
  }else{
    $("#con").hide();
    var alternative_text = document.getElementById("alternative");
    console.log("alternative_text", alternative_text)
    alternative_text.innerHTML = `<p class="alter">There are no attachments</p>`
  }




}
function handleErr(err) {
  console.error(" Error Bro ", err);
}


